module.exports = class Data1745498306185 {
    name = 'Data1745498306185'

    async up(db) {
        await db.query(`CREATE TABLE "block" ("id" character varying NOT NULL, "number" numeric NOT NULL, "hash" text NOT NULL, "parent_hash" text NOT NULL, "timestamp" numeric NOT NULL, CONSTRAINT "PK_d0925763efb591c2e2ffb267572" PRIMARY KEY ("id"))`)
    }

    async down(db) {
        await db.query(`DROP TABLE "block"`)
    }
}
