import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, BigIntColumn as BigIntColumn_, OneToMany as OneToMany_} from "@subsquid/typeorm-store"
import {Snapshot} from "./snapshot.model"

@Entity_()
export class Accounts {
    constructor(props?: Partial<Accounts>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @BigIntColumn_({nullable: false})
    lastSnapshotTimestamp!: bigint

    @OneToMany_(() => Snapshot, e => e.account)
    snapshots!: Snapshot[]
}
