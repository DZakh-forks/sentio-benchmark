import {BigDecimal} from "@subsquid/big-decimal"
import {Entity as Entity_, Column as Column_, PrimaryColumn as PrimaryColumn_, ManyToOne as ManyToOne_, Index as Index_, BigIntColumn as BigIntColumn_, BigDecimalColumn as BigDecimalColumn_} from "@subsquid/typeorm-store"
import {Accounts} from "./accounts.model"

@Entity_()
export class Snapshot {
    constructor(props?: Partial<Snapshot>) {
        Object.assign(this, props)
    }

    @PrimaryColumn_()
    id!: string

    @Index_()
    @ManyToOne_(() => Accounts, {nullable: true})
    account!: Accounts | undefined | null

    @Index_()
    @BigIntColumn_({nullable: false})
    timestamp!: bigint

    @BigDecimalColumn_({nullable: true})
    mintAmount!: BigDecimal | undefined | null

    @BigDecimalColumn_({nullable: false})
    balance!: BigDecimal

    @BigDecimalColumn_({nullable: true})
    point!: BigDecimal | undefined | null
}
