-- Convert timestamps from milliseconds to seconds
UPDATE snapshot SET timestamp = timestamp / 1000;
UPDATE account_registry SET last_snapshot_timestamp = last_snapshot_timestamp / 1000; 