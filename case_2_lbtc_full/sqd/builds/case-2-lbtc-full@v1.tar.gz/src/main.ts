import {TypeormDatabase} from '@subsquid/typeorm-store'
import {Accounts, Snapshot, AccountRegistry, Transfer} from './model'
import {LBTC_PROXY, MULTICALL_ADDRESS} from "./constant.js"
import {processor, Block} from './processor'
import {BigDecimal} from '@subsquid/big-decimal'
import {functions, events} from "./abi/LBTC.js"
import {Multicall} from "./abi/multicall.js"
import {Contract} from "./abi/LBTC.js"

// Add timer variables
let totalRpcTime = 0;
let totalStorageTime = 0;
let totalCalcTime = 0;
let blockCount = 0;
const SECOND_PER_HOUR = 60n * 60n;
const POINTS_PER_DAY = 1000;
const LOG_INTERVAL = 100; // Log every 100 blocks

// Helper function to get account from database
async function getAccountFromDb(store: any, accountId: string): Promise<Accounts | null> {
    const startTime = performance.now();
    const result = await store.findOne(Accounts, {
        where: { id: accountId }
    });
    totalStorageTime += performance.now() - startTime;
    return result;
}

// Helper function to get last snapshot from database
async function getLastSnapshotFromDb(store: any, accountId: string): Promise<Snapshot | null> {
    const startTime = performance.now();
    const result = await store.findOne(Snapshot, {
        where: { account: { id: accountId } },
        order: { timestamp: 'DESC' }
    });
    totalStorageTime += performance.now() - startTime;
    return result;
}

// Helper function to get registry from database
async function getRegistryFromDb(store: any): Promise<AccountRegistry | null> {
    const startTime = performance.now();
    const result = await store.findOne(AccountRegistry, {
        where: { id: "main" }
    });
    totalStorageTime += performance.now() - startTime;
    return result;
}

// Helper function to add account to registry
async function addAccountToRegistry(
    store: any,
    accountId: string
): Promise<void> {
    let registry = await store.get(AccountRegistry, "main")
    if (!registry) {
        registry = new AccountRegistry({
            id: "main",
            accounts: [],
            lastSnapshotTimestamp: 0n
        })
    }
    
    let accountExists = registry.accounts.includes(accountId)
    
    // Add account if it doesn't exist
    if (!accountExists) {
        registry.accounts.push(accountId)
        await store.save(registry)
    }
}

// Helper to get the last snapshot data
async function getLastSnapshotData(
    store: any,
    accountId: string
): Promise<{
    point: BigDecimal,
    balance: BigDecimal,
    timestamp: bigint,
    mintAmount: BigDecimal
}> {
    let lastPoint = BigDecimal(0);
    let lastBalance = BigDecimal(0);
    let lastTimestamp = 0n;
    let lastMintAmount = BigDecimal(0);
    
    const startTime = performance.now();
    let account = await getAccountFromDb(store, accountId);
    totalStorageTime += performance.now() - startTime;
    
    if (account && account.lastSnapshotTimestamp) {
        lastTimestamp = account.lastSnapshotTimestamp;
        
        // If we have a previous snapshot, get it from db
        if (lastTimestamp != 0n) {
            const snapshotStartTime = performance.now();
            let lastSnapshot = await getLastSnapshotFromDb(store, accountId);
            totalStorageTime += performance.now() - snapshotStartTime;
            if (lastSnapshot) {
                lastPoint = lastSnapshot.point || BigDecimal(0);
                lastBalance = lastSnapshot.balance;
                lastMintAmount = lastSnapshot.mintAmount || BigDecimal(0);
            }
        }
    }
    
    return {
        point: lastPoint,
        balance: lastBalance,
        timestamp: lastTimestamp,
        mintAmount: lastMintAmount
    };
}

// Helper to check if it's time for an hourly update
async function shouldUpdateHourly(
    store: any,
    accountId: string, 
    currentTimestamp: bigint
): Promise<boolean> {
    let account = await getAccountFromDb(store, accountId);
    if (!account) return false;
    
    // Check if the account has a lastSnapshotTimestamp and if an hour has passed
    return account.lastSnapshotTimestamp > 0n && 
           (currentTimestamp - account.lastSnapshotTimestamp) >= SECOND_PER_HOUR;
}

// Helper to get or create an account
async function getOrCreateAccount(store: any, address: string): Promise<Accounts> {
  let account = await store.get(Accounts, address)
  
  if (!account) {
    account = new Accounts({
      id: address,
      lastSnapshotTimestamp: 0n
    })
    await store.save(account)
    // Add to registry
    await addAccountToRegistry(store, account.id)
  }
  
  return account
}

// Helper to create and save a snapshot
async function createAndSaveSnapshot(
  store: any,
  accountId: string, 
  timestamp: bigint,
  balance: BigDecimal,
  lastPoint: BigDecimal,
  lastBalance: BigDecimal,
  lastTimestamp: bigint,
  lastMintAmount: BigDecimal,
  snapshotsMap: Map<string, Snapshot> | null,
  accountsToUpdate: Map<string, Accounts> | null,
  isMint: boolean = false,
  mintAmount: bigint = 0n
): Promise<void> {
    // Skip processing for zero address
    if (accountId === "0x0000000000000000000000000000000000000000") {
      return;
    }
  const snapshotKey = `${accountId}-${timestamp}`;
  
  let prevBlock = 0n;
  // Get or create account first
  let account = await store.get(Accounts, accountId);
  if (!account) {
    account = new Accounts({
      id: accountId,
      lastSnapshotTimestamp: 0n
    });
    // Save account first
    await store.save(account);
    // Add to registry
    await addAccountToRegistry(store, accountId);
  }
  
  // Get existing snapshot or create new one
  let snapshot = await store.get(Snapshot, snapshotKey);
  if (!snapshot) {
    snapshot = new Snapshot({
      id: snapshotKey,
      account,
      timestamp: timestamp,
      balance: balance
    });
  } else {
    // Update the balance
    snapshot.balance = balance;
  }
  
  // Handle mint amount if it's a mint transaction
  if (isMint) {
    // If we already have a mintAmount, add to it
    snapshot.mintAmount = snapshot.mintAmount ? 
      snapshot.mintAmount.plus(BigDecimal(mintAmount.toString())) : 
      lastMintAmount.plus(BigDecimal(mintAmount.toString()));
  } else if (!snapshot.mintAmount) {
    // Only set mintAmount if not already set
    snapshot.mintAmount = lastMintAmount;
  }
  
  // Calculate point based on previous values
  const calcStartTime = performance.now();
  if (lastTimestamp != 0n) {
    // Convert timestamps to seconds for calculation
    const timeDiffInSeconds = Number(timestamp - lastTimestamp);
    
    // Calculate points per second (1000 points per day)
    const pointsPerSecond = BigDecimal(POINTS_PER_DAY)
      .div(BigDecimal(24))
      .div(BigDecimal(60))
      .div(BigDecimal(60));
    
    // Calculate new point value
    // Points = lastPoint + (lastBalance * pointsPerSecond * timeDiffInSeconds)
    snapshot.point = lastPoint.plus(
      lastBalance
        .times(pointsPerSecond)
        .times(BigDecimal(timeDiffInSeconds))
    );
  } else {
    // For first snapshot, start with 0 points
    snapshot.point = BigDecimal(0);
  }
  totalCalcTime += performance.now() - calcStartTime;
  
  // Update account's last snapshot timestamp
  account.lastSnapshotTimestamp = timestamp;
  
  // Save snapshot and account
  await store.save(snapshot);
  await store.save(account);
}

processor.run(new TypeormDatabase({supportHotBlocks: true}), async (ctx) => {
    const HOUR_IN_SEC = 60n * 60n
    const transfers: Transfer[] = []
    let prevBlock = 0n
    
    for (let block of ctx.blocks) {
        blockCount++;
        let lbtc = new Contract({_chain: ctx._chain, block: block.header}, LBTC_PROXY)
        let multicall = new Multicall({_chain: ctx._chain, block: block.header}, MULTICALL_ADDRESS)
        const blockTimestamp = BigInt(block.header.timestamp / 1000)
        
        // Process transfers
        for (let log of block.logs) {
            if (log.topics[0] === events.Transfer.topic) {
                // Handle transfer events
                let {from, to, value} = events.Transfer.decode(log)
                
                transfers.push(
                    new Transfer({
                        id: `${block.header.id}_${block.header.height}_${log.logIndex}`,
                        from: from,
                        to: to,
                        value: value,
                        blockNumber: BigInt(block.header.height),
                        transactionHash: log.transaction?.hash ? Buffer.from(log.transaction.hash, 'hex') : null
                    })
                )
                
                // Get balances for both accounts using multicall
                const balanceStartTime = performance.now()
                let multicall = new Multicall({_chain: ctx._chain, block: block.header}, MULTICALL_ADDRESS)
                let balances = await multicall.aggregate(
                    functions.balanceOf,
                    LBTC_PROXY,
                    [{account: from}, {account: to}],
                    100 // batch size to avoid RPC timeouts
                )
                let [fromBalance, toBalance] = balances.flat() // Flatten the array of results
                totalRpcTime += performance.now() - balanceStartTime
                
                // Get last snapshot data for both accounts
                const snapshotStartTime = performance.now()
                let [fromLastData, toLastData] = await Promise.all([
                    getLastSnapshotData(ctx.store, from),
                    getLastSnapshotData(ctx.store, to)
                ])
                totalStorageTime += performance.now() - snapshotStartTime
                
                // Check if this is a mint (from address is zero)
                let isMint = from === "0x0000000000000000000000000000000000000000"
                
                // Create snapshots for both accounts
                if (to !== "0x0000000000000000000000000000000000000000") {
                    await createAndSaveSnapshot(
                        ctx.store,
                        to,
                        blockTimestamp,
                        BigDecimal(toBalance?.toString() || "0"),
                        toLastData.point,
                        toLastData.balance,
                        toLastData.timestamp,
                        toLastData.mintAmount,
                        null,
                        null,
                        isMint,
                        value
                    )
                }
                
                if (!isMint) {
                    await createAndSaveSnapshot(
                        ctx.store,
                        from,
                        blockTimestamp,
                        BigDecimal(fromBalance?.toString() || "0"),
                        fromLastData.point,
                        fromLastData.balance,
                        fromLastData.timestamp,
                        fromLastData.mintAmount,
                        null,
                        null
                    )
                }
            }
        }
        
        // Process hourly updates
        let registry = await getRegistryFromDb(ctx.store)
        if (registry) {
            // Batch balance queries for hourly updates using multicall
            const accountsToUpdate = registry.accounts.filter(accountId => 
                shouldUpdateHourly(ctx.store, accountId, blockTimestamp)
            )
            
            if (accountsToUpdate.length > 0) {
                const balanceStartTime = performance.now()
                let multicall = new Multicall({_chain: ctx._chain, block: block.header}, MULTICALL_ADDRESS)
                let balances = await multicall.aggregate(
                    functions.balanceOf,
                    LBTC_PROXY,
                    accountsToUpdate.map(accountId => ({account: accountId})),
                    100 // batch size to avoid RPC timeouts
                )
                let balanceValues = balances.flat() // Flatten the array of results
                
                for (let i = 0; i < accountsToUpdate.length; i++) {
                    const accountId = accountsToUpdate[i]
                    const balance = balanceValues[i]
                    
                    const snapshotStartTime = performance.now()
                    let lastData = await getLastSnapshotData(ctx.store, accountId)
                    totalStorageTime += performance.now() - snapshotStartTime
                    
                    await createAndSaveSnapshot(
                        ctx.store,
                        accountId,
                        blockTimestamp,
                        BigDecimal(balance?.toString() || "0"),
                        lastData.point,
                        lastData.balance,
                        lastData.timestamp,
                        lastData.mintAmount,
                        null,
                        null
                    )
                }
            }
        }
        
        // Save all transfers
        await ctx.store.save(transfers)
        if (block.header.height > prevBlock + 2000n) {
            console.log(`Processed ${blockCount} blocks:
                Block height: ${block.header.height}
                Total RPC time: ${(totalRpcTime / 1000).toFixed(2)}s
                Total Storage time: ${(totalStorageTime / 1000).toFixed(2)}s
                Total Calculation time: ${(totalCalcTime / 1000).toFixed(2)}s
            `)
            prevBlock = BigInt(block.header.height)
        }
    }
    console.log(`Processed ${blockCount} blocks:
        Total RPC time: ${(totalRpcTime / 1000).toFixed(2)}s
        Total Storage time: ${(totalStorageTime / 1000).toFixed(2)}s
        Total Calculation time: ${(totalCalcTime / 1000).toFixed(2)}s
    `)
})
