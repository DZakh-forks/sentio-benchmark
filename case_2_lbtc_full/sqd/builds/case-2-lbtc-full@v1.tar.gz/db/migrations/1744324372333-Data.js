module.exports = class Data1744324372333 {
    name = 'Data1744324372333'

    async up(db) {
        await db.query(`CREATE TABLE "accounts" ("id" character varying NOT NULL, "last_snapshot_timestamp" numeric NOT NULL, CONSTRAINT "PK_5a7a02c20412299d198e097a8fe" PRIMARY KEY ("id"))`)
        await db.query(`CREATE TABLE "snapshot" ("id" character varying NOT NULL, "timestamp_milli" numeric NOT NULL, "mint_amount" numeric, "balance" numeric NOT NULL, "point" numeric, "account_id" character varying, CONSTRAINT "PK_47b29c1a6055220b1ebdafdf7b5" PRIMARY KEY ("id"))`)
        await db.query(`CREATE INDEX "IDX_b40c06df56e1ac6f97e217aac6" ON "snapshot" ("account_id") `)
        await db.query(`CREATE INDEX "IDX_1bf83b0052273b1ec86b44c081" ON "snapshot" ("timestamp_milli") `)
        await db.query(`CREATE TABLE "account_registry" ("id" character varying NOT NULL, "accounts" text array NOT NULL, "last_snapshot_timestamp" numeric NOT NULL, CONSTRAINT "PK_5bf6b6c93a647641efe9d95b181" PRIMARY KEY ("id"))`)
        await db.query(`CREATE TABLE "transfer" ("id" character varying NOT NULL, "from" text NOT NULL, "to" text NOT NULL, "value" numeric NOT NULL, "block_number" numeric NOT NULL, "transaction_hash" bytea, CONSTRAINT "PK_fd9ddbdd49a17afcbe014401295" PRIMARY KEY ("id"))`)
        await db.query(`CREATE INDEX "IDX_be54ea276e0f665ffc38630fc0" ON "transfer" ("from") `)
        await db.query(`CREATE INDEX "IDX_4cbc37e8c3b47ded161f44c24f" ON "transfer" ("to") `)
        await db.query(`ALTER TABLE "snapshot" ADD CONSTRAINT "FK_b40c06df56e1ac6f97e217aac68" FOREIGN KEY ("account_id") REFERENCES "accounts"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`)
    }

    async down(db) {
        await db.query(`DROP TABLE "accounts"`)
        await db.query(`DROP TABLE "snapshot"`)
        await db.query(`DROP INDEX "public"."IDX_b40c06df56e1ac6f97e217aac6"`)
        await db.query(`DROP INDEX "public"."IDX_1bf83b0052273b1ec86b44c081"`)
        await db.query(`DROP TABLE "account_registry"`)
        await db.query(`DROP TABLE "transfer"`)
        await db.query(`DROP INDEX "public"."IDX_be54ea276e0f665ffc38630fc0"`)
        await db.query(`DROP INDEX "public"."IDX_4cbc37e8c3b47ded161f44c24f"`)
        await db.query(`ALTER TABLE "snapshot" DROP CONSTRAINT "FK_b40c06df56e1ac6f97e217aac68"`)
    }
}
